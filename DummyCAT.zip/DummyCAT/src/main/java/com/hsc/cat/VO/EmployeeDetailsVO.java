package com.hsc.cat.VO;

public class EmployeeDetailsVO {

	private String username;
	private String password;
	private String role;
	private String firstName;
	private String lastName;
	private String department;
	private String managerId;
	private String securityQues1;
	private String securityAns1;
	private String securityQues2;
	private String securityAns2;
	private String email;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getManagerId() {
		return managerId;
	}
	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}
	public String getSecurityQues1() {
		return securityQues1;
	}
	public void setSecurityQues1(String securityQues1) {
		this.securityQues1 = securityQues1;
	}
	public String getSecurityAns1() {
		return securityAns1;
	}
	public void setSecurityAns1(String securityAns1) {
		this.securityAns1 = securityAns1;
	}
	public String getSecurityQues2() {
		return securityQues2;
	}
	public void setSecurityQues2(String securityQues2) {
		this.securityQues2 = securityQues2;
	}
	public String getSecurityAns2() {
		return securityAns2;
	}
	public void setSecurityAns2(String securityAns2) {
		this.securityAns2 = securityAns2;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
