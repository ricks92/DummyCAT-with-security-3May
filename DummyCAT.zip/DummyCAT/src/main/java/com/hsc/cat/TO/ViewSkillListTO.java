package com.hsc.cat.TO;

import java.util.List;

public class ViewSkillListTO {

	private List<ViewSkillTO> listOfEmployeeSkills;

	public List<ViewSkillTO> getListOfEmployeeSkills() {
		return listOfEmployeeSkills;
	}

	public void setListOfEmployeeSkills(List<ViewSkillTO> listOfEmployeeSkills) {
		this.listOfEmployeeSkills = listOfEmployeeSkills;
	}
	
	
}
