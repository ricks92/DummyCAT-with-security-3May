package com.hsc.cat.utilities;

public class Roles {

	 public static final String EMPLOYEE="ROLE_EMPLOYEE";
	 public static final String MANAGER="ROLE_MANAGER";
}
