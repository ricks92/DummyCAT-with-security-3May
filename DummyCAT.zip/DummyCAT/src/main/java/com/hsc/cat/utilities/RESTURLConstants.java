package com.hsc.cat.utilities;

public class RESTURLConstants {

	public static final String BASE_URL="";
	public static final String REGISTER_USER=BASE_URL+"/auth/register";
	public static final String SKILLS=BASE_URL+"/skills";
	public static final String UPDATE_SKILL=BASE_URL+"/updateSkill";
	public static final String VIEW_SKILL=BASE_URL+"/viewSkill/{empId}";
	public static final String FETCH_ALL_EMPLOYEES=BASE_URL+"/manager/employees";
	
	
}
