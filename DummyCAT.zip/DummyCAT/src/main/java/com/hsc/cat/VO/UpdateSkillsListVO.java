package com.hsc.cat.VO;

import java.util.List;

public class UpdateSkillsListVO {
 private List<UpdateSkillVO> listOfEmployeeSkills;

public List<UpdateSkillVO> getListOfEmployeeSkills() {
	return listOfEmployeeSkills;
}

public void setListOfEmployeeSkills(List<UpdateSkillVO> listOfEmployeeSkills) {
	this.listOfEmployeeSkills = listOfEmployeeSkills;
}
 
 
}
