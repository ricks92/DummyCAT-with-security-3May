package com.hsc.cat.utilities;

public class CATException extends Exception{

	public CATException(String message){
		super(message);
	}
}
